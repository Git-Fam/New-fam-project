/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/*
 * クレジットフォームを読み込み時に非表示
 */
$("#creditForm").hide();






/*
 * 入力チェック完了フラグ
 */
var checks = {
    number  :   false,
    expire  :   false,
    name    :   false
};




/*
 * 入力フォームデータ
 */
var inputData = {
    number  :   $(":input[name=number]").val(),
    expire  :   $(":input[name=expireY]").val() + "" + $(":input[name=expireM]").val(),
    name    :   $(":input[name=name]").val()
};








/*
 * すでにチェックしてあれば、表示
 */
var payment = $(":input[name=payment]:checked").val();
if(payment === '1') {
    $("#creditForm").show();
}


$(":input[name=payment]").bind({
    change  :   function(){
        payment = $(":input[name=payment]:checked").val();
        if(payment === '1') {
            $("#creditForm").show();
        } else {
            $("#creditForm").hide();
        }
    }
})







/*
 * クレジットカードチェック用Ajax通信
 */
var creditConnect = function() {
    
    var df = $.Deferred();
    
    $.ajax({
        url         :   '/ajax/credit-card/check',
        dataType    :   'json',
        type        :   'post',
        data        :   {
            number  :   inputData.number,
            expire  :   inputData.expire,
            name    :   inputData.name
        },
        cache       :   false,
        success     :   function() {
            
            
            df.resolve();
        }
    });
    
    
    return df.promise();
}








/*
 * エラーチェック用オブジェクト
 */
var errorCheck = {
    
    numberRegExp    :   /^\d{13,16}$/,
    expireRegExp    :   /^2\d{3}(0|1)\d$/,
    nameRegExp      :   /^[a-zA-Z]+(\s|　)*[a-zA-Z]+$/,
    
    // カード番号チェック用
    number  :   function(number) {
        return this.numberRegExp.test(number);
    },
    
    
    // 有効期限の選択チェック
    expire  :   function(expire) {
        
        // 現在の年月を取得
        var date = new Date();
        var month = ("0" + (date.getMonth() + 1)).slice(-2);
        var checkdate = date.getFullYear() + "" + month;
        
        // エラーフラグ
        var flag = true;
        
        // 現在の日時より遅れていないかどうか
        if(checkdate > expire) {
            flag = false;
        
        // 整合性チェック
        } else if(!this.expireRegExp.test(expire)) {
            flag = false;
        }
        
        return flag;
    },
    
    
    // 名義人名の整合性チェック
    name    :   function(name) {
        return this.nameRegExp.test(name);
    },
    
    
    
    allCheck    :   function() {
        var flag = true;
        for(var key in checks) {
            if(!checks[key]) {
                flag = false;
                break;
            }
        }
        
        // 全て入力されればクレジット番号を確認するためのAjax通信
        if(flag) {
            //console.log(inputData);
        } else {
            //console.log("not value");
        }
    }
};








/*
 * クレジット情報Ajax通信
 */
$("#creditForm :input[name=number], #creditForm :input[name=name]").bind({
    change  :   function() {
        var inputName = $(this).attr('name');
        var value = $(this).val();
        checks[inputName] = errorCheck[inputName](value);
        
        // フォームデータを挿入
        inputData[inputName] = value;
        
        // 全てのデータをチェック後、Ajax通信
        errorCheck.allCheck();
    }
});

$("#creditForm :input[name=expireY], #creditForm :input[name=expireM]").bind({
    change  :   function() {
        var value = $(":input[name=expireY] option:selected").val() + $(":input[name=expireM] option:selected").val();
        checks['expire'] = errorCheck["expire"](value);
        
        // フォームデータを挿入
        inputData['expire'] = value;
        
        // 全てのデータをチェック後、Ajax通信
        errorCheck.allCheck();
    }
});











/*
 * すでに入力されている項目のエラーチェック
 */
for(var datakey in inputData) {
    checks[datakey] = errorCheck[datakey](inputData[datakey]);
}
