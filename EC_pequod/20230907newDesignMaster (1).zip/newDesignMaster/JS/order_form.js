var month_flag      = $(":input[name=month_flag]:checked").val();
 var reg_pase_flag   = $(":input[name=regury_pase]").val();    

 //お届け希望日を切り替えたとき
 $(document).on('change',":input[name=regury_pase]", function() {

     if($(this).val() != 0){
         if($(this).val() == "1W" || $(this).val() == "2W" || $(this).val() == "3W"){
             $("#month_select_area").hide();
             $("#week_select_area").show();
         }else{
             $("#month_select_area").show();
             $("#week_select_area").hide();
         }
     }
 });

 if(reg_pase_flag == "1W" || reg_pase_flag == "2W" || reg_pase_flag == "3W"){
     $("#month_select_area").hide();
     $("#week_select_area").show();
 }else{
     $("#month_select_area").show();
     $("#week_select_area").hide();
 }

 //2回目以降のお届け日の月選択の制御切り替え///////////////////////////////////
 if(month_flag == 1){

     $(":input[name=regury_num_w]").attr("disabled","disabled");
     $(":input[name=regury_select]").attr("disabled","disabled");
     $(":input[name=second_day]").removeAttr("disabled");
     $(":input[name=regury_num_w]").css("background-color","#EFEFEF");
     $(":input[name=regury_select]").css("background-color","#EFEFEF");
     $(":input[name=second_day]").css("background-color","#ffffff");
 }else{
     $(":input[name=regury_num_w]").removeAttr("disabled");
     $(":input[name=regury_select]").removeAttr("disabled");
     $(":input[name=second_day]").attr("disabled","disabled");
     $(":input[name=second_day]").css("background-color","#EFEFEF");
     $(":input[name=regury_num_w]").css("background-color","#ffffff");
     $(":input[name=regury_select]").css("background-color","#ffffff");
 }

 $(document).on('change',":input[name=month_flag]", function() {
     if($(this).val() == 1){
         $(":input[name=regury_num_w]").attr("disabled","disabled");
         $(":input[name=regury_select]").attr("disabled","disabled");
         $(":input[name=second_day]").removeAttr("disabled");
         $(":input[name=regury_num_w]").css("background-color","#EFEFEF");
         $(":input[name=regury_select]").css("background-color","#EFEFEF");
         $(":input[name=second_day]").css("background-color","#ffffff");
     }else{
         $(":input[name=regury_num_w]").removeAttr("disabled");
         $(":input[name=regury_select]").removeAttr("disabled");
         $(":input[name=second_day]").attr("disabled","disabled");
         $(":input[name=second_day]").css("background-color","#EFEFEF");
         $(":input[name=regury_num_w]").css("background-color","#ffffff");
         $(":input[name=regury_select]").css("background-color","#ffffff");
     }
 });
 //2回目以降のお届け日の月選択の制御切り替え///////////////////////////////////
