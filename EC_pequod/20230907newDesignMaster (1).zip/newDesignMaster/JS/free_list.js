$(".errorMessage").html("").hide();
$(".free_table_area").show();

// モーダルウィンドウのセット
var boxCenter = function(id, layer, func) {

    var $windowHeight = $(window).height();
    var $windowWidth = $(window).width();
    var top  = (($windowHeight - parseInt($("#" + id).height())) / 2);
    var left = (($windowWidth - parseInt($("#" + id).width() +24)) / 2);
    $("#" + id).css({
        "top"       :   top + "px",
        "left"      :   left + "px",
        "position"  :   "fixed",
        "z-index"   :   100
    });

    $("#" + layer + ":not(:animated)").css("z-index", 1).fadeIn("fast", function(){
        if(func == undefined) {
            $("#" + id).fadeIn("fast");
        } else {
            $("#" + id).fadeIn("fast", function() {
                func();
            });
        }
    });
};


//受注完了ページ登録ボタンを押したら
$(":input[name=free_submit]").click(function(){
    
    var errors           = new Array();
    var m_free_master_id = new Array(); 
    var m_free_data      = new Array();
    var m_free_title     = new Array();
    var m_free_type      = new Array();
    var m_free_point     = new Array();
    
    
    
    //エラーチェック処理
    $(".free_data").each(function(){
        var free_master_id = $(this).attr("free_master_id");
        var free_required  = $(this).attr("free_required");
        var free_type      = $(this).attr("free_type");
        var free_title     = $(this).val();
        var free_point     = $(this).attr("free_point");
        
        m_free_master_id.push(free_master_id);
        m_free_title[free_master_id] = free_title;
        m_free_type[free_master_id]  = free_type;
        m_free_point[free_master_id] = free_point;
        
        //必須項目であれば
        if(free_required === "2"){
            var free_data = "";
            //テキストタイプ
            if(free_type === "text"){
                free_data     = $("#free_data"+ free_master_id +"").val();
                if(free_data === ""){
                    errors.push(free_title + "を入力してください");
                }else{
                    m_free_data[free_master_id] = free_data;
                }
            }
            
            //テキストボックス
            if(free_type === "textarea"){
                free_data     = $("#free_data"+ free_master_id +"").val();
                if(free_data === ""){
                    errors.push(free_title + "を入力してください");
                }else{
                    m_free_data[free_master_id] = free_data;
                }
            }
            
            //チェックボックス
            if(free_type === "checkbox"){
                var num = 0;
                m_free_data[free_master_id] = ""; 
                $("[name='free_data["+ free_master_id +"][]']:checked").each(function(c) {
                    var flag = $(this).val();
                    if(flag !== ""){
                        num = parseInt(num) + parseInt(1);
                        if(num > 1)m_free_data[free_master_id] += ",";
                        m_free_data[free_master_id] += flag;
                    }
                });
                
                if(num === 0){
                    errors.push(free_title + "を選択してください");
                }
            }
            
        }else{
            var free_data = "";
            //テキストタイプ テキストボックス
            if(free_type === "text" || free_type === "textarea"){
                m_free_data[free_master_id] = $("#free_data"+ free_master_id +"").val();
            }
            
            //チェックボックス
            if(free_type === "checkbox"){
                var num = 0;
                m_free_data[free_master_id] = ""; 
                $("[name='free_data["+ free_master_id +"][]']:checked").each(function(c) {
                    var flag = $(this).val();
                    if(flag !== ""){
                        num = parseInt(num) + parseInt(1);
                        if(num > 1)m_free_data[free_master_id] += ",";
                        m_free_data[free_master_id] += flag;
                    }
                });
            }
        }
        
        //セレクトボックス
        if(free_type === "select"){
            free_data = $("#free_data"+ free_master_id +" option:selected").val();
            m_free_data[free_master_id] = free_data;
        }

        //ラジオボタン
        if(free_type === "radio"){
            free_data = $("#free_data"+ free_master_id +":checked").val();
            m_free_data[free_master_id] = free_data;
        }
        
    });
    
    
    // ひとつでもエラーがあれば、メッセージを表示
    if(errors.length > 0) {
        $(".errorMessage").html("").show();
        $.each(errors, function(i,val) {
            $(".errorMessage").append("<li>"+ val +"</li>");
        });
    // エラーがなければサブミット
    }else {
        //多重クリック防止
        $(this).attr('disabled', true);
        
        var df = $.Deferred();
        
        $(".errorMessage").html("").hide();
        
        var order_id  = $("#free_order_id").val();
        var user_id   = $("#free_user_id").val();
        var free_page = "2";
        
        $.ajax({
            url:'/ajax/free/list',
            dataType: 'json',
            type:"POST",
            data: {
                    user_id:user_id,
                    order_id:order_id,
                    free_master_id:m_free_master_id,
                    free_data:m_free_data,
                    free_title:m_free_title,
                    free_type:m_free_type,
                    free_point:m_free_point,
                    free_page:free_page
                },
                cache:false,
            success : function(json){
                if(json){
                    $(".free_table_area").hide();
                    boxCenter("box", "layer");
                }

                df.resolve();
            },error :function(json){
                console.log(json);
            }
        });
        return df.promise();
        
    }
    
});

//定期購入詳細ページ解約ボタンを押したら
$(":input[name=del_sub]").click(function(){

    var errors           = new Array();
    var m_free_master_id = new Array(); 
    var m_free_data      = new Array();
    var m_free_title     = new Array();
    var m_free_type      = new Array();
    var m_free_point     = new Array();
    
    var response = confirm("解約した定期購入は元に戻せませんがよろしいですか");
    if(response === true){

        //エラーチェック処理
        $(".free_data").each(function(){
            var free_master_id = $(this).attr("free_master_id");
            var free_required  = $(this).attr("free_required");
            var free_type      = $(this).attr("free_type");
            var free_title     = $(this).val();
            var free_point     = $(this).attr("free_point");

            m_free_master_id.push(free_master_id);
            m_free_title[free_master_id] = free_title;
            m_free_type[free_master_id]  = free_type;
            m_free_point[free_master_id] = free_point;

            //必須項目であれば
            if(free_required === "2"){
                var free_data = "";
                //テキストタイプ
                if(free_type === "text"){
                    free_data     = $("#free_data"+ free_master_id +"").val();
                    if(free_data === ""){
                        errors.push(free_title + "を入力してください");
                    }else{
                        m_free_data[free_master_id] = free_data;
                    }
                }

                //テキストボックス
                if(free_type === "textarea"){
                    free_data     = $("#free_data"+ free_master_id +"").val();
                    if(free_data === ""){
                        errors.push(free_title + "を入力してください");
                    }else{
                        m_free_data[free_master_id] = free_data;
                    }
                }

                //チェックボックス
                if(free_type === "checkbox"){
                    var num = 0;
                    m_free_data[free_master_id] = ""; 
                    $("[name='free_data["+ free_master_id +"][]']:checked").each(function(c) {
                        var flag = $(this).val();
                        if(flag !== ""){
                            num = parseInt(num) + parseInt(1);
                            if(num > 1)m_free_data[free_master_id] += ",";
                            m_free_data[free_master_id] += flag;
                        }
                    });

                    if(num === 0){
                        errors.push(free_title + "を選択してください");
                    }
                }
        	}else{
            	var free_data = "";
				//テキストタイプ テキストボックス
	            if(free_type === "text" || free_type === "textarea"){
	                m_free_data[free_master_id] = $("#free_data"+ free_master_id +"").val();
	            }

	            //チェックボックス
	            if(free_type === "checkbox"){
	                var num = 0;
	                m_free_data[free_master_id] = ""; 
	                $("[name='free_data["+ free_master_id +"][]']:checked").each(function(c) {
	                    var flag = $(this).val();
	                    if(flag !== ""){
	                        num = parseInt(num) + parseInt(1);
	                        if(num > 1)m_free_data[free_master_id] += ",";
	                        m_free_data[free_master_id] += flag;
	                    }
	                });
	            }
            }

            //セレクトボックス
            if(free_type === "select"){
                free_data = $("#free_data"+ free_master_id +" option:selected").val();
                m_free_data[free_master_id] = free_data;
            }

            //ラジオボタン
            if(free_type === "radio"){
                free_data = $("#free_data"+ free_master_id +":checked").val();
                m_free_data[free_master_id] = free_data;
            }

        });

        // ひとつでもエラーがあれば、メッセージを表示
        if(errors.length > 0) {
            $(".errorMessage").html("").show();
            $.each(errors, function(i,val) {
                $(".errorMessage").append("<li>"+ val +"</li>");
            });
        }else{
            
            //多重クリック防止
            $(this).attr('disabled', true);

            var df = $.Deferred();

            $(".errorMessage").html("").hide();

            var order_id  = $("#free_order_id").val();
            var user_id   = $("#free_user_id").val();
            var free_page = "4";
            
            $.ajax({
                url:'/ajax/free/list',
                dataType: 'json',
                type:"POST",
                data: {
                        user_id:user_id,
                        order_id:order_id,
                        free_master_id:m_free_master_id,
                        free_data:m_free_data,
                        free_title:m_free_title,
                        free_type:m_free_type,
                        free_point:m_free_point,
                        free_page:free_page
                    },
                    cache:false,
                success : function(json){
                    //解約完了ページにリダイレクト
                    var url = $("#url").val();
                    if(json){
                        $(location).attr("href", url);
                    }

                    df.resolve();
                },error :function(json){
                    console.log(json);
                }
            });
            
            return df.promise();
            
        }
    }
});



//完了メッセージの外側をクリックしたらウィンドウが閉じる処理
$(document).on("click","#layer:not(:animated), .closeLayer", function() {
    $(".modalContent:not(:animated)").hide();
    $("#layer:not(:animated)").css("z-index", 1).fadeOut("fast");
});

//閉じるボタンを押したらウィンドウが閉じる処理
$("#close_window").click(function(){
    $(".modalContent:not(:animated)").hide();
    $("#layer:not(:animated)").css("z-index", 1).fadeOut("fast");
});



