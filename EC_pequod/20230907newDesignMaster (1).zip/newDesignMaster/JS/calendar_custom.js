<!--
//対応までの日数 ex)本日対応であれば0 次の日対応であれば1
	var days = 5
//当日の締切時間をhhmmで入力 ex)7時→0700  15時30分→1530
//締切時間未設定は 2400
	var limit = 2400
//カレンダーのID／複数設置する場合に要設定
	var cal_Id = 'cal_0';

	var calObject = new Object();
	calObject[cal_Id] = new Object();

//Xヵ月後のカレンダーを表示する場合 :: 1は当月
	var cal_display_month = 1;

//注文日・発送日の特別設定
//calObject[cal_Id].tday[ここに受注日を半角で] = "ここに発送日を半角で";
	calObject[cal_Id].tday = new Object();
	calObject[cal_Id].ttext = new Object();
	calObject[cal_Id].tday["2011/5/28"] = "2011/6/6";
	calObject[cal_Id].tday["2011/5/29"] = "2011/6/6";
	calObject[cal_Id].tday["2011/5/30"] = "2011/6/7";
	calObject[cal_Id].tday["2011/5/31"] = "2011/6/9";
	calObject[cal_Id].tday["2011/6/1"] = "2011/6/10";
	calObject[cal_Id].tday["2011/6/2"] = "2011/6/11";



	//定休日などはここで設定します。
	//calObject[cal_Id].day[ここに日にちを半角で] = クラス名;
	calObject[cal_Id].day = new Object();
	calObject[cal_Id].text = new Object();
	calObject[cal_Id].day["2016/8/11"] = "holiday";

	//○日後
	calObject[cal_Id].after = new Array();
	//calObject[cal_Id].after[3] = "deli";

	//毎週○曜日の場合
	calObject[cal_Id].week = new Object();
	calObject[cal_Id].week["flag"] = 1;
	calObject[cal_Id].week["Sun"] = "Sun";
	calObject[cal_Id].week["Mon"];
	calObject[cal_Id].week["Tue"];
	calObject[cal_Id].week["Wed"];
	calObject[cal_Id].week["Thu"];
	calObject[cal_Id].week["Fri"];
	calObject[cal_Id].week["Sat"] = "Sat";

	//毎月○日の場合
	calObject[cal_Id].month = new Object();
	//calObject[cal_Id].month[1] = "openingsale";

	//カレンダーをクリックできるようにする場合
	calObject[cal_Id].click = new Object();
	//パラメータを送るURL
	calObject[cal_Id].click["url"];
	//クリック可能にするクラス名(クラス指定なしの場合は指定せず)
	calObject[cal_Id].click["day"];

	calObject[cal_Id].today = new Date();
	calObject[cal_Id].cal_year = calObject[cal_Id].today.getYear();
	calObject[cal_Id].cal_month = calObject[cal_Id].today.getMonth() + cal_display_month;
	calObject[cal_Id].cal_day = calObject[cal_Id].today.getDate();

function main(){
	if(calObject[cal_Id].cal_year < 1900) calObject[cal_Id].cal_year += 1900;
	if(calObject[cal_Id].cal_month < 1){
		calObject[cal_Id].cal_month += 12;
		calObject[cal_Id].cal_year -= 1;
	}
	else if(calObject[cal_Id].cal_month > 12){
		calObject[cal_Id].cal_month -= 12;
		calObject[cal_Id].cal_year = calObject[cal_Id].cal_year + 1;
	}

	if(cal_display_month == 1){
		calObject[cal_Id].text[calObject[cal_Id].cal_year+"/"+calObject[cal_Id].cal_month+"/"+calObject[cal_Id].cal_day] = "Today";
		for(i=0;i<calObject[cal_Id].after.length;i++){
			if(calObject[cal_Id].after[i] != undefined){
				nmsec = i * 1000 * 60 * 60 * 24;
				msec  = (new Date()).getTime();
				dt    = new Date(nmsec+msec);
				month = dt.getMonth() + 1;
				date  = dt.getDate();
				year = dt.getYear();
				if(year < 1900) year += 1900;
				calObject[cal_Id].day[year+"/"+month+"/"+date] = calObject[cal_Id].after[i];
			}
		}
	}

	document.write("<div class='cal_wrapper'>");
	document.write("<ul class='cal_ui'>");
	document.write("<li class=\"cal_prev\" onclick=\"prevCal('"+cal_Id+"')\"></li>");
	document.write("<li class='cal_to' onclick=\"currentCal('"+cal_Id+"')\"></li>");
	document.write("<li class='cal_next' onclick=\"nextCal('"+cal_Id+"')\"></li>");
	document.write("</ul>");
	document.write("<div id='"+cal_Id+"' class='cal_base'></div>");
	document.write("</div>");

	calObject[cal_Id].to_year = calObject[cal_Id].cal_year;
	calObject[cal_Id].to_month = calObject[cal_Id].cal_month;
	calObject[cal_Id].to_day = calObject[cal_Id].cal_day;
}

function currentCal(calObj){
	calObject[calObj].cal_year = calObject[calObj].to_year;
	calObject[calObj].cal_month = calObject[calObj].to_month;
	calObject[calObj].cal_day = calObject[calObj].to_day;
	writeCal(calObject[calObj].cal_year,calObject[calObj].cal_month,calObject[calObj].cal_day,calObj);
}
function prevCal(calObj){
	calObject[calObj].cal_month -= 1;
	if(calObject[calObj].cal_month < 1){
		calObject[calObj].cal_month = 12;
		calObject[calObj].cal_year -= 1;
	}
	writeCal(calObject[calObj].cal_year,calObject[calObj].cal_month,0,calObj);
}
function nextCal(calObj){
	calObject[calObj].cal_month += 1;
	if(calObject[calObj].cal_month > 12){
		calObject[calObj].cal_month = 1;
		calObject[calObj].cal_year += 1;
	}
	writeCal(calObject[calObj].cal_year,calObject[calObj].cal_month,0,calObj);
}
function getWeek(year,month,day){
	if (month == 1 || month == 2) {
		year--;
		month += 12;
	}
	var week = Math.floor(year + Math.floor(year/4) - Math.floor(year/100) + Math.floor(year/400) + Math.floor((13 * month + 8) / 5) + day) % 7;
	return week;
}
function writeCal(year,month,day,calObj){
	var calendars = new Array(0,31,28,31,30,31,30,31,31,30,31,30,31);
	var weeks = new Array("Sun.","Mon.","Tue.","Wed.","Thu.","Fri.","Sat.");
	var monthName = new Array('','1','2','3','4','5','6','7','8','9','10','11','12');

	var cal_flag = 0;
	if(year % 100 == 0 || year % 4 != 0){
		if(year % 400 != 0){
			cal_flag = 0;
		}
		else{
			cal_flag = 1;
		}
	}
	else if(year % 4 == 0){
		cal_flag = 1;
	}
	else{
		cal_flag = 0;
	}
	calendars[2] += cal_flag;

	var cal_start_day = getWeek(year,month,1);
	var cal_tags = "<p class='cal_month'>" + year + "/" + monthName[month] + "</p>";
	cal_tags += "<ul class='cal_main'>";
	for(var i=0;i<weeks.length;i++){
		cal_tags += "<li class='cal_headline'><span>" + weeks[i] + "</span></li>";
	}
	for(var i=0;i < cal_start_day;i++){
		cal_tags += "<li><span>&nbsp;</span></li>";
	}

	//main
	var first_thu_flag = 1;
	var day_after = null;
	for(var cal_day_cnt = 1;cal_day_cnt <= calendars[month];cal_day_cnt++){
		var cal_day_match = year + "/" + month + "/" + cal_day_cnt;
		var dayClass = "";

		if(calObject[calObj].day[cal_day_match]){
			dayClass = ' class="'+calObject[calObj].day[cal_day_match]+'"';
		}
		else if(calObject[calObj].month[cal_day_cnt] != undefined){
			dayClass = ' class="'+calObject[calObj].month[cal_day_cnt]+'"';
		}
		else if(calObject[calObj].week["flag"] != undefined){
			if(cal_start_day == 0 && calObject[calObj].week["Sun"] != undefined){
				dayClass = ' class="'+calObject[calObj].week["Sun"]+'"';
			}
			else if(cal_start_day == 1 && calObject[calObj].week["Mon"] != undefined){
				dayClass = ' class="'+calObject[calObj].week["Mon"]+'"';
			}
			else if(cal_start_day == 2 && calObject[calObj].week["Tue"] != undefined){
				dayClass = ' class="'+calObject[calObj].week["Tue"]+'"';
			}
			else if(cal_start_day == 3 && calObject[calObj].week["Wed"] != undefined){
				dayClass = ' class="'+calObject[calObj].week["Wed"]+'"';
			}
			else if(cal_start_day == 4 && calObject[calObj].week["Thu"] != undefined){
				dayClass = ' class="'+calObject[calObj].week["Thu"]+'"';
			}
			else if(cal_start_day == 5 && calObject[calObj].week["Fri"] != undefined){
				dayClass = ' class="'+calObject[calObj].week["Fri"]+'"';
			}
			else if(cal_start_day == 6 && calObject[calObj].week["Sat"] != undefined){
				dayClass = ' class="'+calObject[calObj].week["Sat"]+'"';
			}
			else if(ktHolidayName(year + "/" + month + "/" + cal_day_cnt) != ""){
				dayClass = ' class="holiday"';
			}
			else {
				dayClass = ' class="undefined"';
			}
		}
		else {
			dayClass = ' class="undefined"';
		}

		if(calObject[calObj].text[cal_day_match]){
			text_f = "<span class=\""+calObject[calObj].text[cal_day_match]+"\">";
			text_b = "</span>";
		}
		else {
			text_f = "<span>";
			text_b = "</span>";
		}

		//Click to Action
		var clickActions = "";
		if(calObject[calObj].click["day"] == calObject[calObj].day[cal_day_match] && calObject[calObj].click["url"] != undefined)
			clickActions = " onclick=\"location.href='"+calObject[calObj].click["url"]+cal_day_match+"'\"";

		cal_tags += "<li"+dayClass+clickActions+">" + text_f + cal_day_cnt + text_b + "</li>";
		if(cal_start_day == 6){
			cal_start_day = 0;
		}
		else{
			cal_start_day++;
		}
	}
	while(cal_start_day <= 6 && cal_start_day != 0){
		cal_tags += "<li><span>&nbsp;</span></li>";
		cal_start_day++;
	}
	cal_tags += "</ul>";
	document.getElementById(calObj).innerHTML = cal_tags;
}
//writeCal(calObject[cal_Id].cal_year,calObject[cal_Id].cal_month,calObject[cal_Id].cal_day,cal_Id);

//次の発送日をtoLocaleDateStringで返す。
function getDay(){
	//本日の日時を取得
	var d = new Date();
	var dd = new Date();
	//加算するべき日数
	var intDays = 0;

	//dの受注日が発送日特別設定ならその日付を返す

	if(calObject[cal_Id].tday[d.getFullYear() + '/' + (d.getMonth() + 1) + '/' + d.getDate() ] != undefined ){
		dd = calObject[cal_Id].tday[d.getFullYear() + '/' + (d.getMonth() + 1) + '/' + d.getDate() ];
		a = dd.split("/");
		return a[1] + "月" + a[2]  + "日";
	}

	if (dayCheck(d)){
		//締切時間検査
		var h = d.getHours();
		var m = d.getMinutes();
		h= ""+h;
		m= ""+m;
		var hm = eval(h+m);

		if ( hm > limit ){
			//本日から最初の営業日
			d = computeDate(d.getFullYear(),(d.getMonth() + 1), d.getDate(),1);
		while (! dayCheck(d)){
			d = computeDate(d.getFullYear(),(d.getMonth() + 1), d.getDate(),1);
		}
		}

	} else {
		//本日から最初の営業日
		while (! dayCheck(d)){
			d = computeDate(d.getFullYear(),(d.getMonth() + 1), d.getDate(),1);
		}
	}
	//ここまででdは受注日

	//基本対応日数を加算
	intDays += days;

	//intDay分日付を1日ずつずらす。その際dayCheckがfalseを返したらカウントしない。
	while (intDays != 0){
		d = computeDate(d.getFullYear(),(d.getMonth() + 1), d.getDate(),1);
		if (dayCheck(d)){
			intDays -= 1
		}
	}
return (d.getMonth() + 1) + "月" + d.getDate() + "日";
}
//渡された日付が休日ならfalse,営業日ならtrueを返す。
function dayCheck(d){
	var youbi = d.getDay();

	if(youbi == 0 && calObject[cal_Id].week["Sun"] != undefined){
		return false;
	}
	if(youbi == 1 && calObject[cal_Id].week["Mon"] != undefined){
		return false;
	}
	if(youbi == 2 && calObject[cal_Id].week["Tue"] != undefined){
		return false;
	}
	if(youbi == 3 && calObject[cal_Id].week["Wed"] != undefined){
		return false;
	}
	if(youbi == 4 && calObject[cal_Id].week["Thu"] != undefined){
		return false;
	}
	if(youbi == 5 && calObject[cal_Id].week["Fri"] != undefined){
		return false;
	}
	if(youbi == 6 && calObject[cal_Id].week["Sat"] != undefined){
		return false;
	}

	//設定された休日かどうか
	if(calObject[cal_Id].day[d.getFullYear() + '/' + (d.getMonth() + 1) + '/' + d.getDate() ] == "holiday"){
		return false;
	}

	return true;
}

//n日後、n日前の日付を求める
/**
 * 年月日と加算日からn日後、n日前を求める関数
 * year 年
 * month 月
 * day 日
 * addDays 加算日。マイナス指定でn日前も設定可能
 */
function computeDate(year, month, day, addDays) {
	var dt = new Date(year, month - 1, day);
	var baseSec = dt.getTime();
	var addSec = addDays * 86400000;//日数 * 1日のミリ秒数
	var targetSec = baseSec + addSec;
	dt.setTime(targetSec);
	return dt;
}

var MONDAY = 1;
var TUESDAY = 2;
var WEDNESDAY = 3;

// JavaScriptで扱える日付は1970/1/1～のみ
//var cstImplementTheLawOfHoliday = new Date("1948/7/20"); // 祝日法施行
//var cstAkihitoKekkon = new Date("1959/4/10");            // 明仁親王の結婚の儀
var cstShowaTaiso = new Date("1989/2/24");                 // 昭和天皇大喪の礼
var cstNorihitoKekkon = new Date("1993/6/9");              // 徳仁親王の結婚の儀
var cstSokuireiseiden = new Date("1990/11/12");            // 即位礼正殿の儀
var cstImplementHoliday = new Date("1973/4/12");           // 振替休日施行

// [prmDate]には "yyyy/m/d"形式の日付文字列を渡す
function ktHolidayName(prmDate) {
	var MyDate = new Date(prmDate);
	var HolidayName = prvHolidayChk(MyDate);
	var YesterDay;
	var HolidayName_ret;

	if (HolidayName == "") {
		if (MyDate.getDay() == MONDAY) {
			// 月曜以外は振替休日判定不要
			// 5/6(火,水)の判定はprvHolidayChkで処理済
			// 5/6(月)はここで判定する
			if (MyDate.getTime() >= cstImplementHoliday.getTime()) {
				YesterDay = new Date(MyDate.getFullYear(),MyDate.getMonth(),(MyDate.getDate()-1));
				HolidayName = prvHolidayChk(YesterDay);
				if (HolidayName != "") {
					HolidayName_ret = "振替休日";
				} else {
					HolidayName_ret = "";
				}
			} else {
					HolidayName_ret = "";
				}
		} else {
			HolidayName_ret = "";
		}
	} else {
		HolidayName_ret = HolidayName;
	}

	return HolidayName_ret;
}

//===============================================================

function prvHolidayChk(MyDate) {
	var MyYear = MyDate.getFullYear();
	var MyMonth = MyDate.getMonth() + 1;  // MyMonth:1～12
	var MyDay = MyDate.getDate();
	var NumberOfWeek;
	var MyAutumnEquinox;

// JavaScriptで扱える日付は1970/1/1～のみで祝日法施行後なので下記は不要
// if (MyDate.getTime() < cstImplementTheLawOfHoliday.getTime()) {
// return ""; // 祝日法施行(1948/7/20)以前
// } else;

	var Result = "";

// １月 //
	if (MyMonth == 1) {
		if (MyDay == 1) {
			Result = "元日";
		} else {
			if (MyYear >= 2000) {
				NumberOfWeek = Math.floor((MyDay - 1) / 7) + 1;
				if ((NumberOfWeek == 2) && (MyDate.getDay() == MONDAY)) {
					Result = "成人の日";
				} else;
			} else {
				if (MyDay == 15) {
					Result = "成人の日";
				} else;
			}
		}
		return Result;
	} else;

// ２月 //
	if (MyMonth == 2) {
		if (MyDay == 11) {
			if (MyYear >= 1967) {
				Result = "建国記念の日";
			} else;
		} else {
			if (MyDate.getTime() == cstShowaTaiso.getTime()) {
				Result = "昭和天皇の大喪の礼";
			} else;
		}
		return Result;
	} else;

// ３月 //
	if (MyMonth == 3) {
		if (MyDay == prvDayOfSpringEquinox(MyYear)) {  // 1948～2150以外は[99]
			Result = "春分の日";                          // が返るので､必ず≠になる
		} else;
		return Result;
	} else;

// ４月 //
	if (MyMonth == 4) {
		if (MyDay == 29) {
			if (MyYear >= 2007) {
				Result = "昭和の日";
			} else {
				if (MyYear >= 1989) {
					Result = "みどりの日";
				} else {
				Result = "天皇誕生日";
				}
			}
		} else {
			// JavaScriptで扱える日付は1970/1/1～のみなので下記は不要
			// if (MyDate.getTime() == cstAkihitoKekkon.getTime()) {
			//  Result = "皇太子明仁親王の結婚の儀"; // (=1959/4/10)
			// } else;
		}
		return Result;
	} else;

// ５月 //
	if (MyMonth == 5) {
		if (MyDay == 3) {  // ５月３日
			Result = "憲法記念日";
		} else;

		if (MyDay == 4) {  // ５月４日
			if (MyYear >= 2007) {
				Result = "みどりの日";
			} else {
				if (MyYear >= 1986) {
					if (MyDate.getDay() > MONDAY) {
						// 5/4が日曜日は『只の日曜』､月曜日は『憲法記念日の振替休日』(～2006年)
						Result = "国民の休日";
					} else;
				} else;
			}
		} else;

		if (MyDay == 5) {  // ５月５日
			Result = "こどもの日";
		} else;

		if (MyDay == 6) {  // ５月６日
			if (MyYear >= 2007) {
				if ((MyDate.getDay() == TUESDAY) || (MyDate.getDay() == WEDNESDAY)) {
					Result = "振替休日";    // [5/3,5/4が日曜]ケースのみ、ここで判定
				} else;
			} else;
		} else;

		return Result;
	} else;

// ６月 //
	if (MyMonth == 6) {
		if (MyDate.getTime() == cstNorihitoKekkon.getTime()) {
			Result = "皇太子徳仁親王の結婚の儀";
		} else;
		return Result;
	} else;

// ７月 //
	if (MyMonth == 7) {
		if (MyYear >= 2003) {
			NumberOfWeek = Math.floor((MyDay - 1) / 7) + 1;
			if ((NumberOfWeek == 3) && (MyDate.getDay() == MONDAY)) {
				Result = "海の日";
			} else;
		} else {
			if (MyYear >= 1996) {
				if (MyDay == 20) {
					Result = "海の日";
				} else;
			} else;
		}
		return Result;
	} else;

// ８月 //
	if (MyMonth == 8) {
		if (MyYear >= 2016) {
			if (MyDay == 10) {
				Result = "山の日";
			} else;
		}
		return Result;
	} else;

// ９月 //
	if (MyMonth == 9) {
		//第３月曜日(15～21)と秋分日(22～24)が重なる事はない
		MyAutumnEquinox = prvDayOfAutumnEquinox(MyYear);
		if (MyDay == MyAutumnEquinox) {    // 1948～2150以外は[99]
			Result = "秋分の日";              // が返るので､必ず≠になる
		} else {
			if (MyYear >= 2003) {
				NumberOfWeek = Math.floor((MyDay - 1) / 7) + 1;
				if ((NumberOfWeek == 3) && (MyDate.getDay() == MONDAY)) {
					Result = "敬老の日";
				} else {
					if (MyDate.getDay() == TUESDAY) {
						if (MyDay == (MyAutumnEquinox - 1)) {
							Result = "国民の休日";
						} else;
					} else;
				}
			} else {
				if (MyYear >= 1966) {
					if (MyDay == 15) {
						Result = "敬老の日";
					} else;
				} else;
			}
		}
		return Result;
	} else;

// １０月 //
	if (MyMonth == 10) {
		if (MyYear >= 2000) {
			NumberOfWeek = Math.floor(( MyDay - 1) / 7) + 1;
			if ((NumberOfWeek == 2) && (MyDate.getDay() == MONDAY)) {
				Result = "体育の日";
			} else;
		} else {
			if (MyYear >= 1966) {
				if (MyDay == 10) {
					Result = "体育の日";
				} else;
			} else;
		}
		return Result;
	} else;

// １１月 //
	if (MyMonth == 11) {
		if (MyDay == 3) {
			Result = "文化の日";
		} else {
			if (MyDay == 23) {
				Result = "勤労感謝の日";
			} else {
				if (MyDate.getTime() == cstSokuireiseiden.getTime()) {
					Result = "即位礼正殿の儀";
				} else;
			}
		}
		return Result;
	} else;

// １２月 //
	if (MyMonth == 12) {
		if (MyDay == 23) {
			if (MyYear >= 1989) {
				Result = "天皇誕生日";
			} else;
		} else;
		return Result;
	} else;
}

//===================================================================
// 春分/秋分日の略算式は
// 『海上保安庁水路部 暦計算研究会編 新こよみ便利帳』
// で紹介されている式です。
function prvDayOfSpringEquinox(MyYear) {
	var SpringEquinox_ret;

	if (MyYear <= 1947) {
		SpringEquinox_ret = 99;    //祝日法施行前
	} else {
		if (MyYear <= 1979) {
			// Math.floor 関数は[VBAのInt関数]に相当
			SpringEquinox_ret = Math.floor(20.8357 + 
			(0.242194 * (MyYear - 1980)) - Math.floor((MyYear - 1980) / 4));
		} else {
			if (MyYear <= 2099) {
				SpringEquinox_ret = Math.floor(20.8431 + 
				(0.242194 * (MyYear - 1980)) - Math.floor((MyYear - 1980) / 4));
			} else {
				if (MyYear <= 2150) {
					SpringEquinox_ret = Math.floor(21.851 + 
					(0.242194 * (MyYear - 1980)) - Math.floor((MyYear - 1980) / 4));
				} else {
					SpringEquinox_ret = 99;    //2151年以降は略算式が無いので不明
				}

			}
		}
	}
	return SpringEquinox_ret;
}

//=====================================================================
function prvDayOfAutumnEquinox(MyYear) {
	var AutumnEquinox_ret;

	if (MyYear <= 1947) {
			AutumnEquinox_ret = 99; //祝日法施行前
	} else {
		if (MyYear <= 1979) {
			// Math.floor 関数は[VBAのInt関数]に相当
			AutumnEquinox_ret = Math.floor(23.2588 + 
			(0.242194 * (MyYear - 1980)) - Math.floor((MyYear - 1980) / 4));
		} else {
			if (MyYear <= 2099) {
				AutumnEquinox_ret = Math.floor(23.2488 + 
				(0.242194 * (MyYear - 1980)) - Math.floor((MyYear - 1980) / 4));
			} else {
				if (MyYear <= 2150) {
					AutumnEquinox_ret = Math.floor(24.2488 + 
					(0.242194 * (MyYear - 1980)) - Math.floor((MyYear - 1980) / 4));
				} else {
					AutumnEquinox_ret = 99;    //2151年以降は略算式が無いので不明
				}
			}
		}
	}
	return AutumnEquinox_ret;
}
//-->