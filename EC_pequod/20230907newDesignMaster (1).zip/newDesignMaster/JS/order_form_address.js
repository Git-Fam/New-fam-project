/*
 * 入力文字のエスケープ関数
 */
function htmlspecialchars(ch) {
    ch = ch.replace(/&/g, "&amp;");
    ch = ch.replace(/"/g, "&quot;");
    ch = ch.replace(/'/g, "&#039;");
    ch = ch.replace(/</g, "&lt;");
    ch = ch.replace(/>/g, "&gt;");
    return ch;
}
;

/*
 * 別送付先フォームを非表示にしておく
 */
if (!$("#new_add_flag").is(':checked')) {
    $(".new_add_area").hide();
}

/*
 * 別送付先にチェックされたら、入力フォームを表示
 */
$("#new_add_flag").change(function () {
    if ($(this).is(":checked"))
        $(".new_add_area").show();
    else
        $(".new_add_area").hide();
});

//住所が選択されたら
$(document).on("change", ":input[name=address_list]", function () {

    var df = $.Deferred();

    var add_id = $(this).val();

    $.ajax({
        url: '/ajax/order_form',
        dataType: 'json',
        type: "POST",
        data: {
            add_id: add_id
        },
        cache: false,
        success: function (json) {
            if (json) {

                // お名前・フリガナの挿入
                $(":input[name=first_name]").val(json.first_name);
                $(":input[name=last_name]").val(json.last_name);
                $(":input[name=first_name_kana]").val(json.first_name_kana);
                $(":input[name=last_name_kana]").val(json.last_name_kana);

                // 住所の挿入
                $(":input[name=pref_id] option").attr("selected", false);
                $(":input[name=pref_id] option[value=" + json.pref_id + "]").attr('selected', true);
                var postal_code_top = json.postal_code.slice(0, 3);
                var postal_code_under = json.postal_code.slice(3);
                $(":input[name=postal_code_top]").val(postal_code_top);
                $(":input[name=postal_code_under]").val(postal_code_under);
                $(":input[name=address1]").val(json.address1);
                $(":input[name=address2]").val(json.address2);

                // 電話番号の挿入
                $(":input[name=phone]").val(json.phone);
            }
            df.resolve();
        }
    });

    return df.promise();
});
