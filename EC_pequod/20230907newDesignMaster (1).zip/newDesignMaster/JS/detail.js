$(function(){
    
    
    /***************************************************************************
     * 商品詳細ページ 画像処理系
     ***************************************************************************/
    $.fn.imagesLoaded = function(callback){
    var elems = this.filter('img'),
        len = elems.length,
        blank = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";

    elems.bind('load.imgloaded',function(){
        if (--len <= 0 && this.src !== blank){
            elems.unbind('load.imgloaded');
            callback.call(elems,this);
        }
    }).each(function(){
        // cached images don't fire load sometimes, so we reset src.
        if (this.complete || this.complete === undefined){
            var src = this.src;
            // webkit hack from http://groups.google.com/group/jquery-dev/browse_thread/thread/eee6ab7b2da50e1f
            // data uri bypasses webkit log warning (thx doug jones)
            this.src = blank;
            this.src = src;
        }
    });

    return this;
    };
    
    var image_obj;
    $("#detailthumbblock a:not(:animated)").live("click",function(){
        
        image_obj = $(this);
        var relative = image_obj.attr("relative");
        
        $("#detailphoto img:not(:animated)").before("<img src='"+relative+"/item_main_image/"+image_obj.attr("filename")+"' alt=''>");
        $("#detailphoto a").attr("href", relative+"/item_main_image/"+image_obj.attr("filename"));
        
        $("#detailphoto img:first-child").imagesLoaded( function(){
            $("#detailphoto img:last").fadeOut('fast', function(){
                $("#detailphoto img:not(:first-child)").remove();
            });
            
        });
        
        return false;
    })
    
    
    var error_move = $(":input[name=error_move]").val();
    if(error_move == 1) {
        var HashOffset = $("#submit_error").offset().top;
        $("html,body").animate({
        scrollTop: HashOffset
        }, 0);
    }
    
    
    /***************************************************************************
     * TOPまで戻すスクロールしても付いてくるボタン
     ***************************************************************************/
    var topBtn = $('#page-top');   
    topBtn.hide();
    //スクロールが100に達したらボタン表示
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            topBtn.fadeIn();
        } else {
            topBtn.fadeOut();
        }
    });
    //スクロールしてトップ
    topBtn.click(function () {
        $('body,html').animate({
        scrollTop: 0
    }, 500);

    return false;
    });
    
})


