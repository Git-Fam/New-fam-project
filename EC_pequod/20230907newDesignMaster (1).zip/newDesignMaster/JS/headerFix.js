$(function () {
	/* ヘッダ固定 */


	$(window).on("scroll", function () {
		var scrollSize = $("#header").height();
		var scrollVal = $(this).scrollTop();
		if (scrollVal > scrollSize) {
			$("#header").addClass("fixed");
		} else if (scrollVal < scrollSize) {
			$("#header").removeClass("fixed");
		}
	});
});

/* //ヘッダ固定 */