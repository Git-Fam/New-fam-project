/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$(function(){
    
    var item_color;
    var item_id;
    
    $("select[name=item_color]").change(function(){
        
       item_color = $(this).val();
       item_id    = $(this).attr("item_id");
       item_color_obj = $(this);
       
       
       if(item_color != 0){
           $.ajax({
                    url:'/ajax/get-item-size',
                    dataType: 'xml',
                    type:"POST",
                    data: {item_id:item_id,
                           item_color:item_color},
                    cache:false,
               success : function(xml){
                   
                   
                   if(xml) {
                       
                       $('form#data'+item_id+' #item_size').text("")
                       .removeAttr("disabled")
                       .append('<option value="0">選択してください</option>');
                       
                       
                       
                       $("result items", xml).each(function(){
                           $('form#data'+item_id+' #item_size').append($("<option></option>")
                              .val($("item_val", this).text())
                              .html($("item_size", this).text()))
                       })
                   }


               }
          })
      
       }else{
           $('form#data'+item_id+' #item_size').text("");
           $('form#data'+item_id+' #item_size').attr("disabled","");
           $('form#data'+item_id+' #item_size').prepend('<option value="0"">選択してください</option>');
       }
      
      
      
    })

    
})