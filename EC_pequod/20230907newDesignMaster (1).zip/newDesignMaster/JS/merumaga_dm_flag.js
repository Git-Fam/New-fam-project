//メルマガ・DM・パスワードの選択項目を会員登録しないにチェックした時に非表示にする処理

var user_flag = $("input[name='user_flag']:checked").val();

if(user_flag == 1){
    $(".merumaga_area").show();
    $(".dm_area").show();
    $(".password_area").show();
}else{
    $(".merumaga_area").hide();
    $(".dm_area").hide();
    $(".password_area").hide();
}

$(function() {
    $("input[name='user_flag']").click(function(){
        if($(this).val() == 1){
            $(".merumaga_area").show();
            $(".dm_area").show();
            $(".password_area").show();
        }else{
            $(".merumaga_area").hide();
            $(".dm_area").hide();
            $(".password_area").hide();
        }
    });
});


