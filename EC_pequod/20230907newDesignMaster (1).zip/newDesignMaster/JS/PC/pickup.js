// ピックアップ商品一覧(/pickup/list)


$(function () {
	$(".switchList").toggle(
		function(){
			$(this).addClass("swap");
			$(".pickupList").fadeOut("fast", function() {
				$(this).fadeIn("fast").addClass("tileView");
			});
		},
		function(){
			$(this).removeClass("swap");
			$(".pickupList").fadeOut("fast", function() {
				$(this).fadeIn("fast").removeClass("tileView");
			});
		}
	);
});